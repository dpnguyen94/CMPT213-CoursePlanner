package ca.cmpt213.as5.controllers;

import ca.cmpt213.as5.models.*;
import ca.cmpt213.as5.wrappers.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CoursePlannerController {
    private final String FILE_PATH = "data/course_data_2018.csv";

    private CsvFileReader reader = new CsvFileReader();
    List<List<String>> data = reader.getData(FILE_PATH);
    private DataManager manager = new DataManager(data);

    @GetMapping("/api/about")
    public ApiAboutWrapper getAboutMessage() {
        return new ApiAboutWrapper("Course Planner 2020", "Jason Nguyen");
    }

    @GetMapping("/api/dump-model")
    public void dumpModel() {
        for (Subject subject: manager.getSubjects()) {
            for (Course course: subject.getCourses()) {
                System.out.println(subject.getName() + " " + course.getCatalogNbr());
                for (Offering offering: course.getOfferings()) {
                    System.out.println("\t" + offering.getSemester().getCode() + " in " + offering.getLocation() + " by " + offering.getInstructors());
                    for (Section section: offering.getSections()) {
                        System.out.println("\t\tType=" + section.getType() + ", Enrollment=" + section.getEnrollmentTotal() + "/" + section.getEnrollmentCap());
                    }
                }
            }
        }
    }

    @GetMapping("/api/departments")
    public List<ApiDepartmentWrapper> getDepartments() {
        List<ApiDepartmentWrapper> list = new ArrayList<>();
        int index = 0;
        for (Subject subject: manager.getSubjects()) {
            list.add(new ApiDepartmentWrapper(index, subject.getName()));
            index ++;
        }

        return list;
    }

    @GetMapping("/api/departments/{id}/courses")
    public List<ApiCourseWrapper> getCourses(@PathVariable("id") int subjectId) {
        List<ApiCourseWrapper> list = new ArrayList<>();
        int subjectIndex = 0;
        int courseIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            if (subjectIndex == subjectId) {
                for (Course course: subject.getCourses()) {
                    list.add(new ApiCourseWrapper(courseIndex, course.getCatalogNbr()));
                    courseIndex ++;
                }
                return list;
            }
            subjectIndex ++;
        }

        throw new IllegalArgumentException();
    }

    @GetMapping("/api/departments/{subjectId}/courses/{courseId}/offerings")
    public List<ApiCourseOfferingWrapper> getOfferings(@PathVariable("subjectId") int subjectId, @PathVariable("courseId") int courseId) {
        List<ApiCourseOfferingWrapper> list = new ArrayList<>();
        int subjectIndex = 0;
        int courseIndex = 0;
        int offeringIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            if (subjectIndex == subjectId) {
                for (Course course: subject.getCourses()) {
                    if (courseIndex == courseId) {
                        for (Offering offering: course.getOfferings()) {
                            Semester semester = offering.getSemester();
                            list.add(new ApiCourseOfferingWrapper(offeringIndex, offering.getLocation(), offering.getInstructors(),
                                    semester.getTerm(), Integer.parseInt(semester.getCode()), semester.getYear()));

                            offeringIndex ++;
                        }

                        return list;
                    }
                    courseIndex ++;
                }
            }
            subjectIndex ++;
        }

        throw new IllegalArgumentException();
    }

    @GetMapping("/api/departments/{subjectId}/courses/{courseId}/offerings/{offeringId}")
    public List<ApiOfferingSectionWrapper> getSections(@PathVariable("subjectId") int subjectId, @PathVariable("courseId") int courseId, @PathVariable("offeringId") int offeringId) {
        List<ApiOfferingSectionWrapper> list = new ArrayList<>();
        int subjectIndex = 0;
        int courseIndex = 0;
        int offeringIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            if (subjectIndex == subjectId) {
                for (Course course: subject.getCourses()) {
                    if (courseIndex == courseId) {
                        for (Offering offering: course.getOfferings()) {
                            if (offeringIndex == offeringId) {
                                for (Section section: offering.getSections()) {
                                    list.add(new ApiOfferingSectionWrapper(section.getType(), section.getEnrollmentCap(), section.getEnrollmentTotal()));
                                }

                                return list;
                            }
                            offeringIndex ++;
                        }

                        return list;
                    }
                    courseIndex ++;
                }
            }
            subjectIndex ++;
        }


        throw new IllegalArgumentException();
    }

    @PostMapping("/api/addoffering")
    @ResponseStatus(HttpStatus.CREATED)
    public void addOffering(@RequestBody OfferingJSON data) {
        manager.addSubject(data.getSemester(), data.getSubjectName(), data.getCatalogNumber(), data.getLocation(),
                data.getEnrollmentCap(), data.getEnrollmentTotal(), data.getInstructor(), data.getComponent());
        manager.sortData();
    }

    @GetMapping("/api/watchers")
    public List<ApiWatcherWrapper> getWatchers() {
        List<ApiWatcherWrapper> list = new ArrayList<>();

        int subjectIndex = 0;
        int courseIndex = 0;
        int watcherIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            for (Course course: subject.getCourses()) {
                for (CourseObserver observer: course.getObservers()) {
                    ApiDepartmentWrapper subjectWrapper = new ApiDepartmentWrapper(subjectIndex, subject.getName());
                    ApiCourseWrapper courseWrapper = new ApiCourseWrapper(courseIndex, course.getCatalogNbr());

                    list.add(new ApiWatcherWrapper(watcherIndex, subjectWrapper, courseWrapper, observer.getEvents()));
                    watcherIndex ++;
                }
                courseIndex ++;
            }
            subjectIndex ++;
        }

        return list;
    }

    @PostMapping("api/watchers")
    @ResponseStatus(HttpStatus.CREATED)
    public void addWatcher(@RequestBody WatcherJSON watcher) {
        int subjectId = watcher.getDeptId();
        int courseId = watcher.getCourseId();

        int subjectIndex = 0;
        int courseIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            if (subjectIndex == subjectId) {
                for (Course course: subject.getCourses()) {
                    if (courseIndex == courseId) {
                        course.addObserver();
                        return;
                    }
                    courseIndex ++;
                }
            }
            subjectIndex ++;
        }

        throw new IllegalArgumentException();
    }

    @GetMapping("api/watchers/{id}")
    public List<String> getWatcher(@PathVariable("id") int watcherId) {
        int watcherIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            for (Course course: subject.getCourses()) {
                for (CourseObserver observer: course.getObservers()) {
                    if (watcherIndex == watcherId) {
                        return observer.getEvents();
                    }
                    watcherIndex ++;
                }
            }
        }

        throw new IllegalArgumentException();
    }

    @DeleteMapping("/api/watchers/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteWatcher(@PathVariable("id") int watcherId) {
        int watcherIndex = 0;

        for (Subject subject: manager.getSubjects()) {
            for (Course course: subject.getCourses()) {
                for (CourseObserver observer: course.getObservers()) {
                    if (watcherIndex == watcherId) {
                        course.getObservers().remove(observer);
                        return;
                    }
                    watcherIndex ++;
                }
            }
        }

        throw new IllegalArgumentException();
    }

    // Create Exception Handle
    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Request ID not found.")
    @ExceptionHandler(IllegalArgumentException.class)
    public void badIdExceptionHandler() {}
}
