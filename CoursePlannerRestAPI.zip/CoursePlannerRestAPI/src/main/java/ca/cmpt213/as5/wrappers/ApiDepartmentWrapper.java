package ca.cmpt213.as5.wrappers;

public class ApiDepartmentWrapper {
    public int deptId;
    public String name;

    public ApiDepartmentWrapper(int deptId, String name) {
        this.deptId = deptId;
        this.name = name;
    }
}