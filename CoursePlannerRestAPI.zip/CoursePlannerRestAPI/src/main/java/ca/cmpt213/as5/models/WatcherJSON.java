package ca.cmpt213.as5.models;

public class WatcherJSON {
    private int deptId;
    private int courseId;

    public int getDeptId() {
        return deptId;
    }

    public int getCourseId() {
        return courseId;
    }
}
