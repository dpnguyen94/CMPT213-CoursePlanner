package ca.cmpt213.as5.models;

import java.util.ArrayList;
import java.util.List;

public abstract class CourseObserver {
    List<String> events;

    public CourseObserver() {
        events = new ArrayList<>();
    }

    abstract void stateChanged(int semesterCode, int enrollmentCap, int enrollmentTotal, String sectionType);

    public List<String> getEvents() {
        return events;
    };
}
